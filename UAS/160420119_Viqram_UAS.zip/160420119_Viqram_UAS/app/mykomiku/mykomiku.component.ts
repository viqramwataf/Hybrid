import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mykomiku',
  templateUrl: './mykomiku.component.html',
  styleUrls: ['./mykomiku.component.scss'],
})
export class MykomikuComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
