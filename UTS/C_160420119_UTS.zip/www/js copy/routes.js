
var routes = [
  {
    path: '/',
    url: './index.html',
  },
];
