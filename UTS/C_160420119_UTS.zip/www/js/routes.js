
var routes = [
  {
    path: '/',
    url: './index.html',
  },
  {
    path: '/login/',
    url: './login.html',
  },
  {
    path: '/category/',
    url: './category.html',
  },
  {
    path: '/detailcategory/:id',
    url: './detailcategory.html',
  },
  {
    path: '/listcategory/:id',
    url: './listcategory.html',
  },
  {
    path: '/search/',
    url: './search.html',
  },
  {
    path: '/favorite/',
    url: './favorite.html',
  },
];
