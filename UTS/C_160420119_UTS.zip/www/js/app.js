var $$ = Dom7;

var device = Framework7.getDevice();

function getComic(vcari) {
  app.request.post(
    "https://ubaya.fun/hybrid/160420119/uts/comiclist.php", { "cari": vcari },
    function (data) {
      var arr = JSON.parse(data);
      var comic = arr['data'];
      for (var i = 0; i<comic.length; i++) {
        $$("#list_search").append("<li><a href='/listcategory/" + comic[i]['idcomic'] + "'>" + comic[i]["title"] + "</a></li>");
      }
    }
  )
}

var app = new Framework7({
  name: 'Komiku', // App name
  theme: 'auto', // Automatic theme detection
  el: '#app', // App root element

  id: 'io.framework7.myapp', // App bundle ID
  // App store
  store: store,
  // App routes
  routes: routes,


  // Input settings
  input: {
    scrollIntoViewOnFocus: device.cordova && !device.electron,
    scrollIntoViewCentered: device.cordova && !device.electron,
  },
  // Cordova Statusbar settings
  statusbar: {
    iosOverlaysWebView: true,
    androidOverlaysWebView: false,
  },
  on: {
    init: function () {
      var f7 = this;
      if (f7.device.cordova) {
        // Init cordova APIs (see cordova-app.js)
        cordovaApp.init(f7);
      }

      $$(document).on("page:init", function (e, page) {
        if (!localStorage.username) { 
          page.router.navigate('/login/');
        }
        
        // login
        if (page.name == 'login') {
          $$('#btnSignIn').on('click', function(){
            app.request.post('https://ubaya.fun/hybrid/160420119/uts/login.php?',
            { "name":$$("#username").val(),
              "password":$$("#password").val() } , 
              function (data) {
                var arr = JSON.parse(data);
                console.log(arr)     
                var result=arr['result'];
                if (result=='success') {  
                  localStorage.iduser = arr['data']['iduser'];
                  localStorage.username = arr['data']['name'];
                  localStorage.name=$$("#username").val();
                  console.log(localStorage)
                  page.router.back('/'); 
                }
                else app.dialog.alert('Username atau password salah');
              });
          });
          $$('#btnSignOut').on('click', function(){
            localStorage.clear();
            page.router.navigate('/login/');
            console.log(localStorage)
          });
        }
        
        // daftar kategori
        if (page.name == "category") {
          app.request.post("https://ubaya.fun/hybrid/160420119/uts/category.php", {},
          function(data) { 
            var arr = JSON.parse(data);
            comic = arr['data'];
            for (var i=0; i<comic.length; i++){
              $$("#category").append("<br><div><a href='/detailcategory/" + comic[i]['idcategory'] + "' style='background-color: #007AFF;color: white;padding: 14px 25px;text-align: center;text-decoration: none;display: inline-block;border-radius: 7px'>" + comic[i]["name"] + 
              '</a></div><br>');
            } 
          }
          );
        }
        
        if (page.name == "detailcategory") {
          var id = page.router.currentRoute.params.id;
          var idarr = [];
          var avgval = 0;

          app.request.post(
            "https://ubaya.fun/hybrid/160420119/uts/listcategory.php", { "id": id },
            function (data) {
              var arr = JSON.parse(data);
              comic = arr['data'];
              $$("#lblrating" + id).text("Rating: " + avgval);
              console.log("avg " + avgval);
              console.log("");
              for (i=0;i<comic.length;i++){
                // idarr[i] = comic[i]["idcomic"];
                idarr.push(comic[i]["idcomic"]);
                $$('#list_detailcategory').append(
                "<div class='col=50'><div class='card'>" + 
                "<div class='card-header'>" + comic[i]['title'] +"</div>" + 
                "<div class='card-content' style='width:100%; text-align:center;'>" +
                "<img src='" + comic[i]['url_poster'] + "' width='250px;'>" + 
                "<br><label for='' id='lblrating" + comic[i]["idcomic"] + "'>Rating: " + avgval + "</label>" + 
                "<input type='number' id='rating" + comic[i]["idcomic"] + "' min='1' max='100' placeholder=' &emsp;&emsp;&emsp;&emsp;&ensp;Input Rating'>" + 
                "<button id='btnAdd' data='"+comic[i]["idcomic"]+"' class='btnAdd button button-fill' style='height: 40px; border: none;box-shadow: 0 1px 4px grey;'>Submit Rating</button>" +
                "</div>" +
                "<div class='card-footer' style='text-align: justify;'><a href='/listcategory/" + comic[i]['idcomic'] + "'> Read More... </a>" +
                "</div></div></div>");
              }

              for(var j=0; j<idarr.length;j++){
                var id = idarr[j]
                console.log("ID: "+id);
                app.request.post("https://ubaya.fun/hybrid/160420119/uts/ratecomic.php", {"id": id},
                function (data) {
                  var arr = JSON.parse(data);
                  rate = arr['data'];
                  console.log(rate);
                  for(var k=0; k<rate.length;k++){
                    if(rate[k]['avg'] != null){
                      avgval = rate[k]['avg']
                    }
                  }
                  $$("#lblrating" + id).text("Rating: " + avgval);
                  console.log("Rating " + avgval);
                }
              )
              $$("#lblrating" + id).text("Rating: " + avgval);
              console.log("#lblrating " + id);
              }
            }
          );

          // tambah rating komik
          $$(document).on('click', ".btnAdd", function() {
            console.log("test boii")
            console.log($$(this).attr("data"));
            var idkomik = $$(this).attr("data")
            app.request.post('https://ubaya.fun/hybrid/160420119/uts/addrate.php', 
            { iduser: localStorage.getItem("iduser"), idcomic: $$(this).attr("data"), 'rating':$$('#rating'+idkomik).val()},
            function (data) {
              var arr = JSON.parse(data);     
              var fav = arr['result'];
              console.log(arr)
              if (fav == 'success'){
                app.dialog.alert('Thank you for rating!');
              }
              // else app.dialog.alert('Sorry, failed to add comic.');
            });
          });
        }

        // baca komik
        if (page.name == "listcategory") {
          var id = page.router.currentRoute.params.id;
          app.request.post(
            "https://ubaya.fun/hybrid/160420119/uts/detailcategory.php", { "id": id },
            function (data) {
              var arr = JSON.parse(data);    
              comic = arr['data'];           
              for (i=0;i<comic.length;i++){
                $$('#list_category').append("<div style='margin: auto;width: 30%;'><img src='" + comic[i]['url_poster'] + "' width='410px;'>" + 
                "<div style='margin: auto;width:10%;'>" + comic[i]['page'] + "</div></div>");
              }
            }
          );
          $$('#btnFavorite').on('click', function() {
            app.request.post('https://ubaya.fun/hybrid/160420119/uts/addfav.php', { iduser: localStorage.getItem("iduser"), idcomic: id },
            function (data) {
              var arr = JSON.parse(data);     
              var fav = arr['result'];
              console.log(arr)
              if (fav == 'success'){
                app.dialog.alert('Success add comic!');
              }
              else app.dialog.alert('Sorry, failed to add comic.');
            });
          });
        }

        // tambah favorit komik
        if (page.name == "favorite") {
          app.request.post(
            "https://ubaya.fun/hybrid/160420119/uts/userfavcomic.php", { "id": localStorage.getItem("iduser") },
            function (data) {
              var arr = JSON.parse(data);    
              comic = arr['data'];           
              for (i=0;i<comic.length;i++){
                $$('#list_fav').append("<div class='col=50'><div class='card'>" + "<div class='card-header'>" + comic[i]['title'] +
                "</div><div class='card-content' style='width:100%; text-align:center;'>" +
                "<img src='" + comic[i]['url_poster'] + "' width='250px;'>" + 
                "</div>");
              }
            }
          );
        }

        // search komik
        if (page.name == "search") {
          getComic();
          $$("#btnSearch").on("click", function () {
            $$("#list_search").html("");
            getComic($$("#txtcari").val());
          });
        }
      });
    },
  },
});